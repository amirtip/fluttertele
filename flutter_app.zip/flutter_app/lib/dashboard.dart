import 'package:flutter/material.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: ListView(
        children: <Widget>[
          Divider(),
          ListTile(
            leading: CircleAvatar(
              child: Text('M',style: TextStyle(color: Colors.white,fontSize: 20),),
              radius: 30,
              backgroundColor: Colors.blueAccent,
            ),
            title: Text('Mohammad',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
            subtitle: Text('salam che  khabar?'),

            trailing:Icon(Icons.check_circle) ,
          ),
          Divider(),
          ListTile(
            leading: CircleAvatar(
              child: Text('H',style: TextStyle(color: Colors.white,fontSize: 20),),
              radius: 30,
              backgroundColor: Colors.redAccent,
            ),
            title: Text('Hassan',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
            subtitle: Text('fadaaat'),

            trailing:Icon(Icons.check_circle) ,
          ),
          Divider(),
          ListTile(
            leading: CircleAvatar(
              child: Text('N',style: TextStyle(color:Colors.black,fontSize: 20),),
              radius: 30,
              backgroundColor: Colors.pink,

            ),
            title: Text('Nima',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
            subtitle: Text('emtehan darim???'),

            trailing:Icon(Icons.check_circle) ,
          ),
          Divider(),
        ],
      ),
    );
  }
}
