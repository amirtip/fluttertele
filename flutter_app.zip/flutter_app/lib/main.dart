import 'package:flutter/material.dart';


import './dashboard.dart';
void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'text ma app',
    home: Scaffold(
      appBar: AppBar(
        title: Text('Connecting...'),

        elevation: 0,
        //backgroundColor:Colors.redAccent ,
        backgroundColor: Color(0xff0288D1),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.more_vert),
            onPressed: () {},
          )
        ],
      ),
      drawer: Drawer(
        child:ListView(
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text('Amir Golzarodi'),
              accountEmail: Text('mirgolzarodi@gmail.com'),
              decoration: BoxDecoration(
                color: Colors.blueAccent,
              ),

              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.black,
                maxRadius: 10,
                child: Text(
                  'A',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.group),
              title: Text('new group'),
            ),

            ListTile(
              leading: Icon(Icons.person_pin),
              title: Text('profile'),
              onTap: () {
                // change app state..
                //Navigator.pop(context); // close the drawer
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('setting'),
              onTap: () {
                // change app state..
                //Navigator.pop(context); // close the drawer
              },
            ),
            ListTile(
              leading: Icon(Icons.help),
              title: Text('Telegram FAQ'),
              onTap: () {
                // change app state..
                //Navigator.pop(context); // close the drawer
              },
            ),
            ListTile(
              leading: Icon(Icons.share),
              title: Text('share'),
              onTap: () {
                // change app state..
                //Navigator.pop(context); // close the drawer
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.exit_to_app),
              title: Text('Exit'),
              onTap: () {
                // change app state..
                //Navigator.pop(context); // close the drawer
              },
            ),
          ],
        ),
      ),
      body: Dashboard(),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blueAccent,
        elevation: 8,
        onPressed: null,
        child:Icon(
          Icons.comment,
          color: Colors.white,
        ),
      ),
    ),
  ));
}
